const table = document.querySelector('.table tbody')
let sortOrder = true
const data = fetch('/tabla3').then(res => res.json())
data.then(res => {
  sorted(table, res, 'fecha', sortOrder)
})

const sorted = (table, obj, sortBy, sort) => {
  table.innerHTML = ''
  if (typeof obj[0][sortBy] === "number")
    sort ? obj.sort((a, b) => a[sortBy] - b[sortBy]) : obj.sort((a, b) => b[sortBy] - a[sortBy])
  else
    sort ? obj.sort((a, b) => a[sortBy].localeCompare(b[sortBy])) : obj.sort((a, b) => b[sortBy].localeCompare(a[sortBy]))


  obj.forEach(element => {
    table.innerHTML += `
<tr class="table__row" id="${element.id}">
  <td class="table__row-data">
    ${element.nombre}
    </td>
    <td class="table__row-data">
      ${element.descripcion} 
      </td>
      <td class="table__row-data">
        ${element.credito} 
        </td>
        <td class="table__row-data">
          ${new Date(element.fecha).toLocaleDateString()}
          </td>
          <td class="table__row-data">
            ${element.recurrencia}
            </td>
            <td class="table__row-data invisible">
                 ${element.saldo_faltante}
           </td>
            </tr>
            <td colspan="5" class="table__row-data">
            <div class="modal"  id="modal${element.id}"></div>
            </td>
            `
  })
  sortOrder = !sortOrder

  const deudas = document.querySelectorAll('.table__row')

  deudas.forEach(e => {
    e.addEventListener('click', () => {
      const id = e.id
      const tabledata = e.querySelectorAll('.table__row-data')
      const etiqueta = tabledata[0].textContent;
      const descripcion = tabledata[1].textContent;
      const debito = tabledata[2].textContent;
      const fecha = tabledata[3].textContent;
      const recurrencia = tabledata[4].textContent;
      const saldo_faltante = tabledata[5].textContent;
      const modal = document.getElementById("modal" + id)

      const modals = document.querySelectorAll('.modal');
      modals.forEach(e => {
        if (e.id !== id)
          e.innerHTML = ''
      });


      modal.classList.add('modal--open')
      if (recurrencia.trim() === "Otro") {
        modal.innerHTML = `
        <div class="modal__container fade-in">
        <h2 class="modal__title">Saldo faltante <span class="red">${saldo_faltante}</span></h2>
        <div class="modal__content">
        <p class="modal__item"><span>Descripcion:</span> ${descripcion}</p>
        <p class="modal__item"><span>Deuda total:</span> ${debito}</p>
        <p class="modal__item"><span>Monto a pagar:</span> ${debito}</p>
        </div>
        <div class="buttons__container">
        <button class="modal__button modal__close" id="modal__close">Cerrar menu</button>
        <button class="modal__button modal__update" id="modal__close">Actualizar</button>
        <button class="modal__button marcar__pagado" id="modal__close">Pagar!</button>
        <button class="modal__button marcar__finiquitar" id="modal__close">Finiquitar!</button>

        </div>
        </div>
        `
      } else if (recurrencia.trim() === "Mensual") {
        modal.innerHTML = `
          <div class="modal__container fade-in">
          <h2 class="modal__title">Saldo faltante <span class="red">${saldo_faltante}</span></h2>
          <div class="modal__content">
          <p class="modal__item"><span>Descripcion:</span> ${descripcion}</p>
          <p class="modal__item"><span>Deuda total:</span> ${debito}</p>
          <p class="modal__item"><span>Pago Mensual:</span> 500</p>
          </div>
          <div class="buttons__container">
          <button class="modal__button modal__close" id="modal__close">Cerrar menu</button>
          <button class="modal__button modal__update" id="modal__close">Actualizar</button>
          <button class="modal__button marcar__pagado" id="modal__close">Pagar!</button>
          <button class="modal__button marcar__finiquitar" id="modal__close">Finiquitar!</button>

          </div>
          </div>
          `
      } else if (recurrencia.trim() === "Semanal") {
        modal.innerHTML = `
              <div class="modal__container fade-in">
              <h2 class="modal__title">Saldo faltante <span class="red">${saldo_faltante}</span></h2>
              <div class="modal__content">
              <p class="modal__item"><span>Descripcion:</span> ${descripcion}</p>
              <p class="modal__item"><span>Deuda total:</span> ${debito}</p>
              <p class="modal__item"><span>Pago semanal:</span> 500</p>
              </div>
              <div class="buttons__container">
              <button class="modal__button modal__close" id="modal__close">Cerrar menu</button>
              <button class="modal__button modal__update" id="modal__close">Actualizar</button>
              <button class="modal__button marcar__pagado" id="modal__close">Pagar!</button>
              <button class="modal__button marcar__finiquitar" id="modal__close">Finiquitar!</button>
              </div>
              </div>
              `
      } else if (recurrencia.trim() === "Quincenal") {
        modal.innerHTML = `
                  <div class="modal__container fade-in">
                  <h2 class="modal__title">Saldo faltante <span class="red">${saldo_faltante}</span></h2>
                  <div class="modal__content">
                  <p class="modal__item"><span>Descripcion:</span> ${descripcion}</p>
                  <p class="modal__item"><span>Deuda total:</span> ${debito}</p>
                  <p class="modal__item"><span>Pago Quincenal:</span> 500</p>
                  </div>
                  <div class="buttons__container">
                  <button class="modal__button modal__close" id="modal__close">Cerrar menu</button>
                  <button class="modal__button modal__update" id="modal__close">Actualizar</button>
                  <button class="modal__button marcar__pagado" id="modal__close">Pagar!</button>
              <button class="modal__button marcar__finiquitar" id="modal__close">Finiquitar!</button>


                  </div>
                  </div>
                  `
      }
      const cerrarModal = document.querySelector('#modal__close')
      cerrarModal.addEventListener('click', () => {
        modal.classList.remove('modal--open')
        modal.innerHTML = ''
      })
    })
  })

}

const thead = document.querySelectorAll('.table__head-title')
thead[0].addEventListener('click', () => {
  data.then(res => {
    sorted(table, res, 'nombre', sortOrder)
  })
})
thead[1].addEventListener('click', () => {
  data.then(res => {
    sorted(table, res, 'descripcion', sortOrder)
  })
})
thead[2].addEventListener('click', () => {
  data.then(res => {
    sorted(table, res, 'credito', sortOrder)
  })
})
thead[3].addEventListener('click', () => {
  data.then(res => {
    sorted(table, res, 'fecha', sortOrder)
  })
})
thead[4].addEventListener('click', () => data.then(res => sorted(table, res, 'recurrencia', sortOrder))
)