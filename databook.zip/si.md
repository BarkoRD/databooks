











--------------------adolfo

ponerle hover y las flechitas para ordenar los ingresos

agregar los filtros a gastos, creditos propios, creditos externos

ponerle pointer a las tablas

--------------------ricardo

agregar popup de que se agrego un ingreso

boton de finiquitar deuda

hacer codigo de botones guardar/guardarcontinuar de gastos 

que no tenga que ir a avisualizar para que se actualicen los datos de resumen.ejs

hacer los botones actualizar y finiquitar deuda en las opciones de las deudas funcionales

luego de vincularlos hacer que visualizar funcione.

hacer que notificaciones funcione completamente

enviar notificaciones por correo


--------------------adolfo o ricardo

que no se pueda agregar tags vacios
alinear elementos de la pagina para que quede perfectamente cuadrado tanto vertical como horizontalmente


--------------------adolfo Y ricardo

crear el "crear deuda tanto propia como externa"
vincular todos los datos con todo
crear base de datos de notificaciones


BUG ETIQUETAS.
agregar boton de volver a pagina principal de donde esta el formulario
decile a adolfo que se ordene automaticamente por fecha por default